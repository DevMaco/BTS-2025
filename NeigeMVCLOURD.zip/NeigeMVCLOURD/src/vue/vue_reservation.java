package vue;

import javax.swing.*;

public class vue_reservation extends JFrame {
    public vue_reservation() {
        setTitle("Gestion des réservations");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }
}
