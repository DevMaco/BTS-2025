module NeigeMVCLOURD {
    requires java.desktop;
    requires java.sql;

    exports app;
    exports vue;
    exports modele;
}
