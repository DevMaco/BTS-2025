package controleur;

import vue.Vue_login;

public class Main {
    public static void main(String[] args) {
        new Vue_login();
    }
}
