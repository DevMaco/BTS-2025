/**
 * 
 */
/**
 * 
 */
module NeigeSoleil2 {
	requires java.sql;
	requires java.desktop;
}